
// UsingWinHeadlessView.h : interface of the CUsingWinHeadlessView class
//


#pragma once


class CUsingWinHeadlessView : public CEditView
{
protected: // create from serialization only
	CUsingWinHeadlessView();
	DECLARE_DYNCREATE(CUsingWinHeadlessView)

// Attributes
public:
	CUsingWinHeadlessDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CUsingWinHeadlessView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in UsingWinHeadlessView.cpp
inline CUsingWinHeadlessDoc* CUsingWinHeadlessView::GetDocument() const
   { return reinterpret_cast<CUsingWinHeadlessDoc*>(m_pDocument); }
#endif

