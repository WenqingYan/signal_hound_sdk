
// UsingWinHeadlessView.cpp : implementation of the CUsingWinHeadlessView class
//

#include "stdafx.h"
#include "UsingWinHeadless.h"

#include "UsingWinHeadlessDoc.h"
#include "UsingWinHeadlessView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CUsingWinHeadlessView

IMPLEMENT_DYNCREATE(CUsingWinHeadlessView, CEditView)

BEGIN_MESSAGE_MAP(CUsingWinHeadlessView, CEditView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

// CUsingWinHeadlessView construction/destruction

CUsingWinHeadlessView::CUsingWinHeadlessView()
{
	// TODO: add construction code here

}

CUsingWinHeadlessView::~CUsingWinHeadlessView()
{
}

BOOL CUsingWinHeadlessView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}


// CUsingWinHeadlessView printing

BOOL CUsingWinHeadlessView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CUsingWinHeadlessView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CUsingWinHeadlessView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}


// CUsingWinHeadlessView diagnostics

#ifdef _DEBUG
void CUsingWinHeadlessView::AssertValid() const
{
	CEditView::AssertValid();
}

void CUsingWinHeadlessView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CUsingWinHeadlessDoc* CUsingWinHeadlessView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CUsingWinHeadlessDoc)));
	return (CUsingWinHeadlessDoc*)m_pDocument;
}
#endif //_DEBUG


// CUsingWinHeadlessView message handlers
