
// UsingWinHeadlessDoc.h : interface of the CUsingWinHeadlessDoc class
//


#pragma once


class CUsingWinHeadlessDoc : public CDocument
{
protected: // create from serialization only
	CUsingWinHeadlessDoc();
	DECLARE_DYNCREATE(CUsingWinHeadlessDoc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CUsingWinHeadlessDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnSignalhoundStart();
};


