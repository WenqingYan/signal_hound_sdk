#include "AudioStream.h"

class CAudioSampler {
public:
	CAudioSampler();
	~CAudioSampler(void);

	int ReadAudioChunk(short *buffer, int *count);

	// Interface to old AudioStream Class	
	CAudioStream *stream;

private:
	short *from_dev;
	float *work;
	int rollover;

	double origdataR[8]; //For recursive filter
	double procdataR[8];
	double AudioRecursiveFilter(double dataIn);

};
