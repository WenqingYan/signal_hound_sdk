Spike SA-series API for ARM-Linux
---------------------------------

As Linux distributions vary these instructions are a guide to installation 
and use.  Signal Hound has tested the driver and samples with Raspbian 
on the Raspberry Pi 2.

The SA-series API uses FTDI's libftd2xx.

libftd2xx uses an unmodified version of libusb 
(http://sourceforge.net/projects/libusb/).  

Installing the shared libraries
-------------------------------

1.  Extract files from sa_api_arm_3_0_5.tar.gz

2.  cd path/to/this/folder/
3.  sudo -s 

Promotes you to super-user

4.  cp lib/g++#.#.#/libsa_api.* /usr/local/lib

Replace #.#.# with the appropriate version. 
Read the versions notes in the lib/ directory to determine which version is appropriate. 
Copies the library to your build/link path.

5. cp lib/libftd2xx.so.1.1.12 /usr/local/lib

Copy the ftdi library to your build/link path.

5.  chmod 0755 /usr/local/lib/libftd2xx.so.1.1.12
6.  chmod 0755 /usr/local/lib/libsa_api.so.3.#.#

Allows non-root access to the shared object.

7.  ln -sf /usr/local/lib/libftd2xx.so.1.1.12 /usr/local/lib/libftd2xx.so
8.  ln -sf /usr/local/lib/libsa_api.so.3.#.# /usr/local/lib/libsa_api.so

Creates a symbolic links to the libraries

9. cp sh_device.rules /etc/udev/rules.d/sh_device.rules
10. cp hound-blacklist.conf /etc/modprobe.d/hound-blacklist.conf 

11. Reboot.

API Manual
-------------------------------

Visit 
www.signalhound.com/sigdownloads/SA API Manual.pdf
for the programming manual. Covers all available function in the API.
Note, the ARM API build is a reduced set and only some of the functionality in the manual is available in the API. See the header file for a full list of functions in the ARM build.
